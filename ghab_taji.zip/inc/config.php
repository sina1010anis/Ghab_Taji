<?php
$server="localhost";
$database="ghab_taji";
$username="root";
$password="";
$dsn="mysql:host=$server;dbname=$database";
$link=new PDO($dsn,$username,$password ,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));



