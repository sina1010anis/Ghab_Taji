<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/class_shit.css">
    <link rel="stylesheet" href="css/product.css">
    <script src="https://kit.fontawesome.com/d4c29863c5.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="container_S">
    <div class="row_S">
        <div id="menu">
            <ul style="margin: 0;padding: 0">
                <?php
                    include 'inc/menu.php';
                ?>
            </ul>
        </div>
    </div>
</div>

</body>
</html>
