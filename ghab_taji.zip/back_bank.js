$("#btn_back_site").click(function () {
    window.location.href='panel_user.php?user=basket';
})