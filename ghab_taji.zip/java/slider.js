$('.single-item').slick({
    autoplay: true,
    autoplaySpeed: 2000,
});