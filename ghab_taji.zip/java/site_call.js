$("#need").hover(function () {
    $("#need").stop().animate({
        width:'300',
        opacity:1
    },500);
    $("#icon2").stop().animate({
        left:'120',
        opacity:1
    },500);
    $("#icon3").stop().animate({
        left:'200',
        opacity:1
    },500);
    $("#icon4").stop().animate({
        left:'280',
        opacity:1
    },500)
},function () {
    $("#icon2").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#icon3").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#icon4").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#need").stop().animate({
        width:'0',
        opacity:0
    },1000);
});



$("#icon").hover(function () {
    $("#need").stop().animate({
        width:'300',
        opacity:1
    },500);
    $("#icon2").stop().animate({
        left:'120',
        opacity:1
    },500);
    $("#icon3").stop().animate({
        left:'200',
        opacity:1
    },500);
    $("#icon4").stop().animate({
        left:'280',
        opacity:1
    },500)
    //$("#icon2").addClass('left120');
},function () {

    $("#icon2").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#icon3").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#icon4").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#need").stop().animate({
        width:'0',
        opacity:0
    },1000);
    //$("#icon2").addClass('left30');
});

$("#icon2").hover(function () {
    $("#need").stop().animate({
        width:'300',
        opacity:1
    },500);
    $("#icon2").stop().animate({
        left:'120',
        opacity:1
    },500);
    $("#icon3").stop().animate({
        left:'200',
        opacity:1
    },500);
    $("#icon4").stop().animate({
        left:'280',
        opacity:1
    },500)
    //$("#icon2").addClass('left120');
},function () {

    $("#icon2").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#icon3").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#icon4").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#need").stop().animate({
        width:'0',
        opacity:0
    },1000);
    //$("#icon2").addClass('left30');
});

$("#icon3").hover(function () {
    $("#need").stop().animate({
        width:'300',
        opacity:0
    },500);
    $("#icon2").stop().animate({
        left:'120',
        opacity:1
    },500);
    $("#icon3").stop().animate({
        left:'200',
        opacity:1
    },500);
    $("#icon4").stop().animate({
        left:'280',
        opacity:1
    },500)
    //$("#icon2").addClass('left120');
},function () {

    $("#icon2").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#icon3").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#icon4").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#need").stop().animate({
        width:'0',
        opacity:0
    },1000);
    //$("#icon2").addClass('left30');
});

$("#icon4").hover(function () {
    $("#need").stop().animate({
        width:'300',
        opacity:0
    },500);
    $("#icon2").stop().animate({
        left:'120',
        opacity:1
    },500);
    $("#icon3").stop().animate({
        left:'200',
        opacity:1
    },500);
    $("#icon4").stop().animate({
        left:'280',
        opacity:1
    },500)
    //$("#icon2").addClass('left120');
},function () {

    $("#icon2").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#icon3").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#icon4").stop().animate({
        left:'30',
        opacity:0
    },500);
    $("#need").stop().animate({
        width:'0',
        opacity:0
    },1000);
    //$("#icon2").addClass('left30');
})