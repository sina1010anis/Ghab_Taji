<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/footer.css">
    <script src="https://kit.fontawesome.com/d4c29863c5.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/class_shit.css">
    <link rel="stylesheet" href="css/all_product.css">
    <link rel="stylesheet" href="tools/slick-theme.css">
    <link rel="stylesheet" href="tools/slick.css">
    <link rel="stylesheet" href="tools/owl.theme.default.min.css">
    <link rel="stylesheet" href="tools/owl.carousel.min.css">
</head>
<body>
<div id="container" class="container_S">
    <div class="row_S">
        <div id="footer">
                <span id="part_1_footer">
                    <h4>درباره قاب تاجی</h4>
                    <hr class="hr">
                    <a>  تاریخچه <i class="fas fa-address-book"></i></a>
                    <a>بنیان گذار <i class="fas fa-user-tie"></i></a>
                    <a>مسئول فروش <i class="fas fa-user-check"></i></a>
                    <a>سازنده ها <i class="fas fa-hammer"></i></a>
                </span>
            <span id="part_2_footer">

                                    <h4>حساب کاربری</h4>
                    <hr class="hr">
                    <a>عضویت <i class="fas fa-user-edit"></i></a>
                    <a>ورود <i class="fas fa-sign-in-alt"></i></a>
                    <a href="index.php">صفحه نخست <i class="fas fa-home"></i></a>
                </span>
            <span id="part_3_footer">
                                                    <h4>راه های ارتباطی</h4>
                    <hr class="hr">
                    <a> 3122222 <i class="fas fa-phone-alt"></i></a>
                    <a> 00000000000 <i class="fas fa-mobile"></i></a>
                    <a> 00000000000 <i class="fas fa-mobile"></i></a>
            </span>
            <span id="part_4_footer">
                <span id="col_s_lef"></span>
                <span id="col_s_right"></span>
            </span>
            <p class="copy_text">1399 - 1399 © تمامی حقوق این سایت متعلق به قاب تاجی می باشد، هرگونه کپی برداری از آن پیگرد قانونی خواهد داشت</p>
        </div>
    </div>
</div>
</body>
</html>
