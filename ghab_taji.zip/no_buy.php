<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/class_shit.css">
    <link rel="stylesheet" href="css/ok_send.css">
    <script src="tools/jquery-3.3.1.min.js"></script>
    <script src="https://kit.fontawesome.com/d4c29863c5.js" crossorigin="anonymous"></script>
</head>
<body>
<?php
include 'header.php'
?>
<div id="container" class="container_S">
    <div class="row_S">
        <p align="center">
            <i class="far fa-sad-tear"></i>

        </p>
        <h3 id="pm_err"> تراکنش با خطا مواجه شد</h3>
        <div id="btn_back_site" href="#">بازگشت به پنل کاربری</div>
    </div>
</div>
</body>
<script src="back_bank.js"></script>
</html>