<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/icon.css">
    <script src="tools/jquery-3.3.1.min.js"></script>
</head>
<body>
<div id="ssm">
    <div id="need"></div>
    <div id="icon"><i class="fas fa-phone-volume"></i></div>
    <div id="icon2"><i class="fab fa-instagram"></i></div>
    <div id="icon3"><i class="fab fa-telegram-plane"></i></div>
    <div id="icon4"><i class="fab fa-whatsapp"></i></div>
</div>

</body>
<script src="java/site_call.js"></script>
</html>
