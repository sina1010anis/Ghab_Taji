<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="../tools/jquery-3.3.1.min.js"></script>
    <style>
        @font-face {
            font-family: 'IRANS';
            src: url('../font/IRANSansWeb.ttf');
        }
        .font{
            font-size: 12px;
        }
        *{text-align: center}
    </style>
</head>
<body style="background-color: white!important;">
<span style="border: #545454 1px solid;color: #545454;padding: 5px 20px;border-radius: 200px">حذف  یک عکس از محصول</span>
<div style="width: 600px;height: auto;border: black 1px solid;border-radius: 20px;box-shadow: #363636 1px 1px 10px;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);padding: 25px;box-sizing: border-box">

    <div class="form-group">
        <label style="width: 100%" for="exampleInputEmail2">ایدی عکس</label>
        <input style="width: 100%" name="id_p" type="text" class="form-control" id="exampleInputEmail2" placeholder="ایدی عکس">
    </div>
    <button id="edit_status" style="font-family: 'IRANS'" type="submit" class="btn btn-success">تایید</button>

</div>
</body>
<script>
    $("#edit_status").click(function () {
        var id=$("input[name=id_p]").val();
        $.ajax({
            url:"search_photo_delete.php",
            data:{id:id},
            type:"POST",
        }).done(function (msg) {
            alert('عکسی با ایدی'+ id+ 'حذف شد.');
        })
    })
</script>
</html>
