<?php
include '../inc/config.php';
$sql="INSERT INTO `tbl_off` (`id`, `code`, `off`) VALUES (NULL, '".$_POST['code']."', '".$_POST['number']."')";
$stmt=$link->prepare($sql);
$stmt->execute();