<?php
include '../inc/config.php';
$sql = "INSERT INTO `tbl_imgs` (`id`, `id_img`, `img`) VALUES (NULL,'".$_POST['id']."', '".$_POST['photo']."')";
$stmt=$link->prepare($sql);
$stmt->execute();