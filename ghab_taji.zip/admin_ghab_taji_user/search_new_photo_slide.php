<?php
include '../inc/config.php';
$sql = "INSERT INTO `tbl_img_slide` (`id`, `img`) VALUES (NULL,'" . $_POST['idS'] . "')";
$stmt = $link->prepare($sql);
$stmt->execute();