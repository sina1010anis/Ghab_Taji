<?php
session_start();
if (!isset($_SESSION['admin_name_user'])) {
    header("location: index.php");
}
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../tools/bootstrap.min.css">
    <link rel="stylesheet" href="../tools/bootstrap-theme.min.css">
    <link rel="stylesheet" href="../css/admin_style.css">
    <script src="../tools/jquery-3.3.1.min.js"></script>
    <script src="../tools/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">پنل مدریتی</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">برسی سبد خرید کاربران <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="?menu=all_basket">مشاهده کل سفارشات</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="?menu=search_basket">مشاهده سفارشات (براساس کد کاربری)</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">خرید نهایی <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="?menu=buy_all">برسی کل سفارشات </a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="?menu=buy_name">جستجو بر اساس نام</a></li>
                        <li><a href="?menu=buy_mobile">جستو جو بر اساس شماره موبایل</a></li>
                        <li><a href="?menu=buy_code">جستوجو بر اساس کد کاربری</a></li>
                        <li><a href="?menu=buy_codeT">جستوجو بر اساس کد تراکنش</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="?menu=edit_status">تغییر وضعیت محصول خریداری شده</a></li>

                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">اضافه کردن عکس <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="?menu=photo_product">مشاهده تمامی ادرس ها (تک محصول ها)</a></li>
                        <li><a href="?menu=photo_new_product">اضافه کردن ادرس جدید(تک محصول)</a></li>
                        <li><a href="?menu=photo_delete">حذف کردن ادرس (تک محصول)</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="?menu=photo_slider">مشاهده تمامی ادرس ها (اسلایدر)</a></li>
                        <li><a href="?menu=photo_new_slide">اضافه کردن ادرس جدید(اسلایدر)</a></li>
                        <li><a href="?menu=photo_delete_slide">حذف کردن ادرس (اسلایدر)</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">منو <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="?menu=menu">مشاهده تمامی منو ها</a></li>
                        <li><a href="?menu=menu_new">اضافه کردن منو جدید</a></li>
                        <li><a href="?menu=menu_delete">حذف منو</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">کد تخفیف ها <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="?menu=off">مشاهده کل تخفیفات</a></li>
                        <li><a href="?menu=new_off">اضافه کردن کد تخفیف جدید</a></li>
                        <li><a href="?menu=delete_off">حذف کد تخفیف</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">پیام ها<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="?menu=pm_oun_panel">مشاهده کل پیام ها(تک پیام پنل کاربری)</a></li>
                        <li><a href="?menu=pm_new_panel">پیام جدید(تک پیام پنل کاربری)</a></li>
                        <li><a href="?menu=pm_delete_panel">حذف پیام(تک پیام پنل کاربری)</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="?menu=pm_product">مشاهده کل پیام ها(نظرات)</a></li>
                        <li><a href="?menu=pm_product_admin">مشاهده کل پیام ها مدیر(نظرات)</a></li>
                        <li><a href="?menu=pm_new_product">پیام جدید(نظرات)</a></li>
                        <li><a href="?menu=pm_edit_product">تغییر وضعیت پیام(نظرات)</a></li>
                        <li><a href="?menu=pm_delete_product">حذف پیام(نظرات)</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="?menu=pm_admin_user">مشاهده کل پیام ها(ارتباط با کاربر)</a></li>
                        <li><a href="?menu=pm_admin_user_admin">مشاهده کل پیام مدیر(ارتباط با کاربر)</a></li>
                        <li><a href="?menu=pm_new_admin_user">پیام جدید(ارتباط با کاربر)</a></li>
                        <li><a href="?menu=pm_delete_admin_user">حذف پیام کاربر(ارتباط با کاربر)</a></li>
                        <li><a href="?menu=pm_delete_admin_user_admin">حذف پیام مدیر(ارتباط با کاربر)</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">محصولات <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="?menu=product_all">مشاهده کل محصولات</a></li>
                        <li><a href="?menu=product_edit_price">تغییر قیمت</a></li>
                        <li><a href="?menu=product_new">اضافه کردن محصول جدید</a></li>
                        <li><a href="?menu=product_delete">حذف محصول</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">کاربران <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="?menu=user_all">مشاهده کل کاربران</a></li>
                        <li><a href="?menu=user_delete">بن کردن کاربر</a></li>
                    </ul>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<?php
switch ($_GET['menu']) {
    case 'all_basket':
        include 'all_basket.php';
        break;
    case 'search_basket':
        include 'search_basket.php';
        break;
    case 'buy_all':
        include 'buy_all.php';
        break;
    case 'buy_name':
        include 'buy_name.php';
        break;
    case 'buy_mobile':
        include 'buy_mobile.php';
        break;
    case 'buy_code':
        include 'buy_code.php';
        break;
    case 'buy_codeT':
        include 'buy_codeT.php';
        break;
    case 'edit_status':
        include 'edit_status.php';
        break;
    case 'photo_product':
        include 'photo_product.php';
        break;
    case 'photo_new_product':
        include 'photo_new_product.php';
        break;
    case 'photo_delete':
        include 'photo_delete.php';
        break;
    case 'photo_slider':
        include 'photo_slider.php';
        break;
    case 'photo_new_slide':
        include 'photo_new_slide.php';
        break;
    case 'photo_delete_slide':
        include 'photo_delete_slide.php';
        break;
    case 'menu':
        include 'menu.php';
        break;
    case 'menu_new':
        include 'menu_new.php';
        break;
    case 'menu_delete':
        include 'menu_delete.php';
        break;
    case 'off':
        include 'off.php';
        break;
    case 'new_off':
        include 'new_off.php';
        break;
    case 'delete_off':
        include 'delete_off.php';
        break;
    case 'pm_oun_panel':
        include 'pm_oun_panel.php';
        break;
    case 'pm_new_panel':
        include "pm_new_panel.php";
        break;
    case 'pm_delete_panel':
        include 'pm_delete_panel.php';
        break;
    case 'pm_product':
        include 'pm_product.php';
        break;
    case 'pm_new_product':
        include 'pm_new_product.php';
        break;
    case 'pm_delete_product':
        include 'pm_delete_product.php';
        break;
    case 'pm_product_admin':
        include 'pm_product_admin.php';
        break;
    case 'pm_edit_product':
        include 'pm_edit_product.php';
        break;
    case 'pm_admin_user':
        include 'pm_admin_user.php';
        break;
    case 'pm_new_admin_user':
        include 'pm_new_admin_user.php';
        break;
    case 'pm_admin_user_admin':
        include 'pm_admin_user_admin.php';
        break;
    case 'pm_delete_admin_user':
        include 'pm_delete_admin_user.php';
        break;
    case 'pm_delete_admin_user_admin':
        include 'pm_delete_admin_user_admin.php';
        break;
    case 'product_all':
        include 'product_all.php';
        break;
    case 'product_new':
        include 'product_new.php';
        break;
    case 'product_delete':
        include 'product_delete.php';
        break;
    case 'product_edit_price':
        include 'product_edit_price.php';
        break;
    case 'user_all':
        include 'user_all.php';
        break;
    case 'user_delete':
        include 'user_delete.php';
        break;
}
?>
</body>
</html>
