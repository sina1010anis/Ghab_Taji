<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="../tools/jquery-3.3.1.min.js"></script>
    <style>
        @font-face {
            font-family: 'IRANS';
            src: url('../font/IRANSansWeb.ttf');
        }
        .font{
            font-size: 12px;
        }
        *{text-align: center}
    </style>
</head>
<body style="background-color: white!important;">
<span style="border: #545454 1px solid;color: #545454;padding: 5px 20px;border-radius: 200px">اضافه کردن منو جدید</span>
<div style="width: 600px;height: auto;border: black 1px solid;border-radius: 20px;box-shadow: #363636 1px 1px 10px;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);padding: 25px;box-sizing: border-box">

    <div class="form-group">
        <label style="width: 100%" for="exampleInputEmail2">نام</label>
        <input style="width: 100%" name="name_m" type="text" class="form-control" id="exampleInputEmail2" placeholder="نام">
    </div>
    <div class="form-group">
        <label style="width: 100%" for="exampleInputEmail2">ادرس ایکون</label>
        <input style="width: 100%" name="icon_m" type="text" class="form-control" id="exampleInputEmail2" placeholder="ادرس ایکون">
    </div>
    <div class="form-group">
        <label style="width: 100%" for="exampleInputEmail2">ادرس مرورگر</label>
        <input style="width: 100%" name="goo_m" type="text" class="form-control" id="exampleInputEmail2" placeholder="ادرس مرورگر">
    </div>
    <button id="edit_status" style="font-family: 'IRANS'" type="submit" class="btn btn-success">تایید</button>

</div>
</body>
<script>
    $("#edit_status").click(function () {
        var name=$("input[name=name_m]").val();
        var icon=$("input[name=icon_m]").val();
        var goo=$("input[name=goo_m]").val();
        $.ajax({
            url:"search_menu_new.php",
            data:{name:name , icon:icon , goo:goo},
            type:"POST",
        }).done(function (msg) {
            alert('ایتم '+name+' با ادرس ایکون '+icon+' و ادرس مرورگر  '+ goo +' اضافه شد ')
        })
    })
</script>
</html>
