<?php
include '../inc/config.php';
$id=$_POST['id'];
$sql="delete from tbl_pm_send_admin where id='".$id."'";
$stmt=$link->prepare($sql);
$stmt->execute();