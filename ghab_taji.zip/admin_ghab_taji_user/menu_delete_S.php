<?php
include '../inc/config.php';
$sql = "DELETE FROM tbl_menu WHERE id = '".$_POST['name']."' ";
$stmt=$link->prepare($sql);
$stmt->execute();