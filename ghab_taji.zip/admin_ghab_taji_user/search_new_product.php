<?php
include '../inc/config.php';
$name=$_POST['name'];
$price=$_POST['price'];
$img=$_POST['img'];
$code=$_POST['code'];
$item_1=$_POST['item_1'];
$item_2=$_POST['item_2'];
$item_3=$_POST['item_3'];
$item_4=$_POST['item_4'];
$item_5=$_POST['item_5'];
$model=$_POST['model'];
$COMP=$_POST['COMP'];
$sql = "INSERT INTO `tbl_product` (`id`, `name`, `price`, `img`, `code`, `item_1`, `item_2`, `item_3`, `item_4`, `item_5`, `COMP` , `buy` ,`model`)
 VALUES (NULL, '$name', '$price', '$img', '$code', '$item_1', '$item_2', '$item_3', '$item_4', '$item_5', '$COMP' , 0 , '$model')";
$stmt=$link->prepare($sql);
$stmt->execute();
