<?php
include '../inc/config.php';
$name=$_POST['name'];
$price=$_POST['titel'];
$sql="update tbl_product set price='".$price."' where id='".$name ."'";
$stmt=$link->prepare($sql);
$stmt->execute();
