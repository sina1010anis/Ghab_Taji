<?php
include '../inc/config.php';
$sql="delete from tbl_off where id='".$_POST['code']."'";
$stmt=$link->prepare($sql);
$stmt->execute();