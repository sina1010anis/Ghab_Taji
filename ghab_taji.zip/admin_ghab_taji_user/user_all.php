<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color: white!important;">
<table class="table table-bordered">
    <tr>
        <th class="font success">ایدی</th>
        <th class="font success">نام</th>
        <th class="font success">ایمیل</th>
        <th class="font success">پسورد</th>
        <th class="font success">شماره موبایل</th>
        <th class="font success">شهر</th>
    </tr>
    <?php

    include '../inc/config.php';
    $sql = "select * from tbl_user_s";
    $stmt = $link->prepare($sql);
    $stmt->execute();
    while ($n = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $id = $n['id'];
        $name = $n['name_U'];
        $email = $n['email_U'];
        $pass= $n['password_U'];
        $mobile = $n['mobile_U'];
        $city = $n['city_U'];
        echo '<tr>';
        echo '<th class="font danger">'.$id.'</th>';
        echo '<th class="font">'.$name.'</th>';
        echo '<th class="font">'.$email.'</th>';
        echo '<th class="font">'.$pass.'</th>';
        echo '<th class="font">'.$mobile.'</th>';
        echo '<th class="font">'.$city.'</th>';
        echo '</tr>';
    }

    ?>
</table>
</body>
</html>
