<?php
include '../inc/config.php';
$sql = "delete from tbl_pm_product where id='" . $_POST['code'] . "'";
$stmt = $link->prepare($sql);
$stmt->execute();