<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../tools/bootstrap.min.css">
    <link rel="stylesheet" href="../tools/bootstrap-theme.min.css">
    <link rel="stylesheet" href="../css/admin_style.css">
    <script src="../tools/jquery-3.3.1.min.js"></script>
    <script src="../tools/bootstrap.min.js"></script>
</head>
<body style="background-color: white!important;">
<table class="table table-bordered">
    <tr>
        <th>ایدی</th>
        <th>کد کاربری</th>
        <th>ایدی محصول سفارش داده شده</th>
        <th>تعداد سفارش داده شده</th>
        <th>وضعیت سفارش</th>
    </tr>
    <?php

    include '../inc/config.php';
    $sql = "select * from tbl_basket where cookiename like '%" . @$_POST['code_user'] . "%'";
    $stmt = $link->prepare($sql);
    $stmt->execute();
    while ($n = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $id = $n['id'];
        $cookie = $n['cookiename'];
        $number = $n['numbers'];
        $id_P = $n['id_P'];
        $T_buy = $n['T_buy'];
        echo '<tr>';
        echo '<th>' . $id . '</th>';
        echo '<th>' . $cookie . '</th>';
        echo '<th>' . $id_P . '</th>';
        echo '<th>' . $number . '</th>';
        if ($T_buy == 0) {
            echo '<th>' . 'هنوز پرداخت نشده' . '</th>';
        }
        if ($T_buy == 200) {
            echo '<th>' . 'پرداخت شده' . '</th>';
        }
        if ($T_buy == 404) {
            echo '<th>' . 'پرداخت با خطا مواجه شده' . '</th>';
        }

        echo '</tr>';
    }

    ?>
</table>
</body>
</html>
