<?php
include '../inc/config.php';
$name=$_POST['name'];
$id=$_POST['id'];
$text=$_POST['text'];
$sql = "INSERT INTO `tbl_pm_send_admin` (`id`, `user`, `pm`, `name`) VALUES (NULL, '$id', '$name', '$text')";
$stmt=$link->prepare($sql);
$stmt->execute();