<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color: white!important;">
<table class="table table-bordered">
    <tr>
        <th class="font success">ایدی</th>
        <th class="font success">نام</th>
        <th class="font success">ایکون</th>
        <th class="font success">ادرس مرورگر</th>
    </tr>
    <?php

    include '../inc/config.php';
    $sql = "select * from tbl_menu";
    $stmt = $link->prepare($sql);
    $stmt->execute();
    while ($n = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $id = $n['id'];
        $name = $n['name'];
        $icon = $n['icon'];
        $href = $n['href'];
        echo '<tr>';
        echo '<th class="font danger">'.$id.'</th>';
        echo '<th class="font">'.$name.'</th>';
        echo '<th class="font">'.$icon.'</th>';
        echo '<th class="font">'.$href.'</th>';
        echo '</tr>';
    }

    ?>
</table>
</body>
</html>
