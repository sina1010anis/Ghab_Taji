<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        @font-face {
            font-family: 'IRANS';
            src: url('../font/IRANSansWeb.ttf');
        }
        .font{
            font-size: 12px;
        }
    </style>
</head>
<body style="background-color: white!important;">
<table class="table table-bordered">
    <tr>
        <th class="font success">ایدی</th>
        <th class="font success">ایدی عکس</th>
        <th class="font success">ادرس عکس</th>
    </tr>
    <?php

    include '../inc/config.php';
    $sql = "select * from tbl_imgs";
    $stmt = $link->prepare($sql);
    $stmt->execute();
    while ($n = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $id = $n['id'];
        $id_img = $n['id_img'];
        $img = $n['img'];
        echo '<tr>';
        echo '<th class="font danger">'.$id.'</th>';
        echo '<th class="font">'.$id_img.'</th>';
        echo '<th class="font">'.$img.'</th>';
        echo '</tr>';
    }
    ?>
</table>
</body>
</html>

