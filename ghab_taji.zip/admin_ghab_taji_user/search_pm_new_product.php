<?php
include '../inc/config.php';
$id=$_POST['id'];
$name=$_POST['name'];
$text=$_POST['text'];
$sql = "INSERT INTO `tbl_pm_admin_product` (`id`, `name`, `text`, `id_pm`) VALUES (NULL, '$name', '$text', '$id')";
$stmt=$link->prepare($sql);
$stmt->execute();