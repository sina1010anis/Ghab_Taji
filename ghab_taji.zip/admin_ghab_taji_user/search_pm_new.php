<?php
include '../inc/config.php';
include '../tools/jdf.php';
$name=$_POST['name'];
$titel=$_POST['titel'];
$text=$_POST['text'];
$date=jdate('Y/n/j  H:i:s');
$sql = "INSERT INTO `tbl_pm_admin` (`id`, `email_user`, `titel_pm`, `text_pm`, `date`) VALUES (NULL, '$name', '$titel', '$text', '$date')";
$stmt=$link->prepare($sql);
$stmt->execute();