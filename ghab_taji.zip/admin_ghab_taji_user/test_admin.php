<?php
session_start();
$user=$_POST['user_name'];
$pass=$_POST['pass'];
$user_md5=md5(md5(md5($user)));
$pass_md5=md5(md5(md5($pass)));
include '../inc/config.php';
$sql="select * from tbl_S_admin where username=? and password=?";
$stmt=$link->prepare($sql);
$stmt->bindValue(1,$user_md5);
$stmt->bindValue(2,$pass_md5);
$stmt->execute();
$num=$stmt->rowCount();
if ($num == 1){
    $_SESSION['admin_name_user']=$user;
    echo 'need_a';
}else{
    echo '1';
}