<?php
include '../inc/config.php';
$sql="select * from tbl_basket where cookiename like '%".@$_POST['text']."%'";
$stmt=$link->prepare($sql);
$stmt->execute();
while ($n=$stmt->fetch(PDO::FETCH_ASSOC)){
$id=$n['id'];
$cookie=$n['cookiename'];
$number=$n['numbers'];
$id_P=$n['id_P'];
$T_buy=$n['T_buy'];
echo '<tr>';
    echo '<th>'.$id.'</th>';
    echo '<th>'.$cookie.'</th>';
    echo '<th>'.$id_P.'</th>';
    echo '<th>'.$number.'</th>';
    if ($T_buy == 0){
    echo '<th>'.'هنوز پرداخت نشده'.'</th>';
    }        if ($T_buy == 200){
    echo '<th>'.'پرداخت شده'.'</th>';
    }        if ($T_buy == 404){
    echo '<th>'.'پرداخت با خطا مواجه شده'.'</th>';
    }

    echo '</tr>';
}
