<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        @font-face {
            font-family: 'IRANS';
            src: url('../font/IRANSansWeb.ttf');
        }
        .font{
            font-size: 12px;
        }
    </style>
</head>
<body style="background-color: white!important;">

<table class="table table-bordered">
    <tr>
        <th class="font success">ایدی</th>
        <th class="font success">نام</th>
        <th class="font success">نام خانوادگی</th>
        <th class="font success">شهر</th>
        <th class="font success">ادرس</th>
        <th class="font success">شماره موبایل</th>
        <th class="font success">تلفن منزل</th>
        <th class="font success">وضعیت پرداختی</th>
        <th class="font success">کد کاربری</th>
        <th class="font success">نام کاربری</th>
        <th class="font success">تاریخ و زمان</th>
        <th class="font success">محصولات سفارش داده شده</th>
        <th class="font success">تعداد سفارشات</th>
        <th class="font success">مجموع کل قیمت</th>
        <th class="font success">کد دریافتی درگاه</th>
        <th class="font success">کد تراکنشی</th>
        <th class="font success">وضعیت سفارش</th>
    </tr>
    <?php

    include '../inc/config.php';
    $sql = "select * from tbl_buy ORDER BY `tbl_buy`.`id` DESC";
    $stmt = $link->prepare($sql);
    $stmt->execute();
    while ($n = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $id = $n['id'];
        $name = $n['name_user'];
        $family = $n['family_user'];
        $city_user = $n['city_user'];
        $location_user = $n['location_user'];
        $mobile_yser = $n['mobile_yser'];
        $phoneHome_user = $n['phoneHome_user'];
        $T_buy = $n['T_buy'];
        $cookiename = $n['cookiename'];
        $user_name = $n['user_name'];
        $date = $n['date'];
        $product_buy = $n['product_buy'];
        $number_buy = $n['number_buy'];
        $total_price = $n['total_price'];
        $token = $n['token'];
        $code_t = $n['code_t'];
        $status = $n['status'];
        echo '<tr>';
        echo '<th class="font danger">'.$id.'</th>';
        echo '<th class="font">'.$name.'</th>';
        echo '<th class="font">'.$family.'</th>';
        echo '<th class="font">'.$city_user.'</th>';
        echo '<th class="font">'.$location_user.'</th>';
        echo '<th class="font">'.$mobile_yser.'</th>';
        echo '<th class="font">'.$phoneHome_user.'</th>';
        echo '<th class="font">'.$T_buy.'</th>';
        echo '<th class="font">'.$cookiename.'</th>';
        echo '<th class="font">'.$user_name.'</th>';
        echo '<th class="font">'.$date.'</th>';
        echo '<th class="font">'.$product_buy.'</th>';
        echo '<th class="font">'.$number_buy.'</th>';
        echo '<th class="font">'.$total_price.'</th>';
        echo '<th class="font">'.$token.'</th>';
        echo '<th class="font">'.$code_t.'</th>';
        echo '<th class="font">'.$status.'</th>';
        echo '</tr>';
    }

    ?>
</table>
</body>
</html>
