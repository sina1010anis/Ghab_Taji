<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../tools/bootstrap.min.css">
    <link rel="stylesheet" href="../tools/bootstrap-theme.min.css">
    <link rel="stylesheet" href="../css/admin_css">
    <script src="../tools/jquery-3.3.1.min.js"></script>
    <script src="../tools/bootstrap.min.js"></script>
</head>
<body>
<div id="need_admin">
    <div class="form-group">
        <label class="font" for="exampleInputEmail1">یوزر نام</label>
        <input name="user" type="email" class="form-control font" id="exampleInputEmail1" placeholder="یوزر نام">
    </div>
    <div class="form-group">
        <label class="font" for="exampleInputPassword1">پسورد</label>
        <input name="pass" type="password" class="form-control font" id="exampleInputPassword1" placeholder="پسورد">
    </div>
    <button type="submit" class="btn btn-default font">ورود</button>
</div>
</body>
<script>
    $(".btn-default").click(function () {
        var user_name=$('input[name=user]').val();
        var pass=$('input[name=pass]').val();
        if (user_name == '' || pass == ''){
            alert('یکی از فیلد ها خالی است')
        }else {
            $.ajax({
                url:'test_admin.php',
                data:{user_name:user_name , pass:pass},
                type:'POST'
            }).done(function (msg) {
                if (msg == '1'){
                    alert('نام کاربری یا پسورد اشتباه است');
                }if (msg == 'need_a'){
                    window.location.href=msg+'.php?menu=all_basket';
                }
            })
        }

    });
</script>
</html>