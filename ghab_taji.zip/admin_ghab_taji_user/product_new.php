<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        @font-face {
            font-family: 'IRANS';
            src: url('../font/IRANSansWeb.ttf');
        }
        .font{
            font-size: 12px;
        }
        *{text-align: center}
    </style>
</head>
<body style="background-color: white!important;">
<span style="border: #545454 1px solid;color: #545454;padding: 5px 20px;border-radius: 200px">اضافه کردن محصول جدید (راهنمای دسته بندی  0 به معنی هیچ دسته در قسمت اول سایت می اید - 1 منو نمونه فریم - 2 تابلو نقاشی - 3 تابلو تزیینی - 4 تایلو دکوراتیو - 5 ست های دکوراتیو - 6 قاب ایینه - 7 ابزار ها )</span>
<div style="width: 600px;height: auto;border: black 1px solid;border-radius: 20px;box-shadow: #363636 1px 1px 10px;position: absolute;top: 100%;left: 50%;transform: translate(-50%, -50%);padding: 25px;box-sizing: border-box">
    <div class="form-group">
        <label for="exampleInputEmail2">نام محصول جدید</label>
        <input name="name_p" type="text" class="form-control" id="exampleInputEmail2" placeholder="نام محصول جدید">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail2">قیمت محصول (ریال)</label>
        <input name="price_p" type="text" class="form-control" id="exampleInputEmail2" placeholder="قیمت محصول (ریال)">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail2">ادرس عکس (ویترین)</label>
        <input name="img_p" type="text" class="form-control" id="exampleInputEmail2" placeholder="ادرس عکس">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail2">کد محصول</label>
        <input name="code_p" type="text" class="form-control" id="exampleInputEmail2" placeholder="کد محصول">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail2">ایتم 1</label>
        <input name="item_1" type="text" class="form-control" id="exampleInputEmail2" placeholder="ایتم 1">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail2">ایتم 2</label>
        <input name="item_2" type="text" class="form-control" id="exampleInputEmail2" placeholder="ایتم 2">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail2">ایتم 3</label>
        <input name="item_3" type="text" class="form-control" id="exampleInputEmail2" placeholder="ایتم 3">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail2">ایتم 4</label>
        <input name="item_4" type="text" class="form-control" id="exampleInputEmail2" placeholder="ایتم 4">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail2">ایتم 5</label>
        <input name="item_5" type="text" class="form-control" id="exampleInputEmail2" placeholder="ایتم 5">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail2">دسته بندی</label>
        <input name="model_p" type="text" class="form-control" id="exampleInputEmail2" placeholder="نوع دسته بندی">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail2">توضیحات</label>
        <textarea style="max-width: 100%;max-height: 1000px;min-width: 100%;min-height: 50px" name="COMP_p" type="text" class="form-control text_A" id="exampleInputEmail2" placeholder="توضیحات"></textarea>
    </div>
    <button style="font-family: 'IRANS'" type="submit" class="btn btn-success">تایید</button>
</div>
</body>
<script>
    $(".btn-success").click(function () {
        var name=$("input[name=name_p]").val();
        var model=$("input[name=model_p]").val();
        var price=$("input[name=price_p]").val();
        var img=$("input[name=img_p]").val();
        var code=$("input[name=code_p]").val();
        var item_1=$("input[name=item_1]").val();
        var item_2=$("input[name=item_2]").val();
        var item_3=$("input[name=item_3]").val();
        var item_4=$("input[name=item_4]").val();
        var item_5=$("input[name=item_5]").val();
        var COMP=$(".text_A").val();
        alert(COMP);

        $.ajax({
            url:"search_new_product.php",
            type:"POST",
            data:{model:model ,name:name , price:price , img:img , code:code , item_1:item_1 , item_2:item_2 , item_3:item_3 , item_4:item_4 , item_5:item_5 , COMP:COMP},
        }).done(function () {
            alert(' محصول با موفقیت اضافه شد ');
        })
    });
</script>
</html>
