<?php
include '../inc/config.php';
$sql = "INSERT INTO `tbl_menu` (`id`, `name`, `icon` , `href`) VALUES (NULL,'" . $_POST['name'] . "', '" . $_POST['icon'] . "' , '".$_POST['goo']."')";
$stmt = $link->prepare($sql);
$stmt->execute();