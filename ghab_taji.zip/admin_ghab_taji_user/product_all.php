<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color: white!important;">
<table class="table table-bordered">
    <tr>
        <th class="font success">ایدی</th>
        <th class="font success">نام</th>
        <th class="font success">قیمت(ریال)</th>
        <th class="font success">ادرس عکس</th>
        <th class="font success">کد کالا</th>
        <th class="font success">ایتم یک</th>
        <th class="font success">ایتم دو</th>
        <th class="font success">ایتم سه</th>
        <th class="font success">ایتم چهار</th>
        <th class="font success">ایتم پنج</th>
        <th class="font success">توضیحات</th>
    </tr>
    <?php

    include '../inc/config.php';
    $sql = "select * from tbl_product ORDER BY `id` DESC";
    $stmt = $link->prepare($sql);
    $stmt->execute();
    while ($n = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $id = $n['id'];
        $name = $n['name'];
        $price = $n['price'];
        $img = $n['img'];
        $code = $n['code'];
        $item_1 = $n['item_1'];
        $item_2 = $n['item_2'];
        $item_3 = $n['item_3'];
        $item_4 = $n['item_4'];
        $item_5 = $n['item_5'];
        $COMP = $n['COMP'];
        echo '<tr>';
        echo '<th class="font danger">'.$id.'</th>';
        echo '<th class="font">'.$name.'</th>';
        echo '<th class="font">'.$price.'</th>';
        echo '<th class="font">'.$img.'</th>';
        echo '<th class="font">'.$code.'</th>';
        echo '<th class="font">'.$item_1.'</th>';
        echo '<th class="font">'.$item_2.'</th>';
        echo '<th class="font">'.$item_3.'</th>';
        echo '<th class="font">'.$item_4.'</th>';
        echo '<th class="font">'.$item_5.'</th>';
        echo '<th class="font">'.$COMP.'</th>';
        echo '</tr>';
    }

    ?>
</table>
</body>
</html>
