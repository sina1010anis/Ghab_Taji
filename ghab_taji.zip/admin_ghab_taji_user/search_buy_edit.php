<?php
include '../inc/config.php';
$code=$_POST['code'];
$id=$_POST['id'];
$sql = "update tbl_buy set status='".$code."' where id='".$id."'";
$stmt = $link->prepare($sql);
$stmt->execute();
echo 'ok';