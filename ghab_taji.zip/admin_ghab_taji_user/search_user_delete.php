<?php
include '../inc/config.php';
$sql = "DELETE FROM tbl_user_s WHERE id = '" . $_POST['name'] . "' ";
$stmt = $link->prepare($sql);
$stmt->execute();