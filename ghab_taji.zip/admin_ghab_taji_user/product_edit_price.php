<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        @font-face {
            font-family: 'IRANS';
            src: url('../font/IRANSansWeb.ttf');
        }
        .font{
            font-size: 12px;
        }
        *{text-align: center}
    </style>
</head>
<body style="background-color: white!important;">
<span style="border: #545454 1px solid;color: #545454;padding: 5px 20px;border-radius: 200px">تغییر قیمت یک محصول</span>
<div style="width: 600px;height: auto;border: black 1px solid;border-radius: 20px;box-shadow: #363636 1px 1px 10px;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);padding: 25px;box-sizing: border-box">
    <div class="form-group">
        <label for="exampleInputEmail2">ایدی محصول</label>
        <input name="name_pm" type="text" class="form-control" id="exampleInputEmail2" placeholder="ایدی محصول">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail2">قیمت جدید</label>
        <input name="titel_pm" type="text" class="form-control" id="exampleInputEmail2" placeholder="قیمت جدید">
    </div>
    <button style="font-family: 'IRANS'" type="submit" class="btn btn-success">ارسال</button>
</div>
</body>
<script>
    $(".btn-success").click(function () {
        var name=$("input[name=name_pm]").val();
        var titel=$("input[name=titel_pm]").val();
        $.ajax({
            url:"search_product_edit_price.php",
            type:"POST",
            data:{name:name , titel:titel},
        }).done(function () {
            alert('با موفقیت قیمتت تغییر کرد')
        })
    });
</script>
</html>
