<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color: white!important;">
<table class="table table-bordered">
    <tr>
        <th class="font success">ایدی</th>
        <th class="font success">نام</th>
        <th class="font success">ایدی محصول نظر داده شده</th>
        <th class="font success">متن</th>
        <th class="font success">تاریخ</th>
        <th class="font success">وضعیت انتشار</th>
    </tr>
    <?php

    include '../inc/config.php';
    $sql = "select * from tbl_pm_product ORDER BY `id` DESC";
    $stmt = $link->prepare($sql);
    $stmt->execute();
    while ($n = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $id = $n['id'];
        $name = $n['name'];
        $id_P = $n['id_P'];
        $text = $n['text'];
        $date = $n['date'];
        $V_S = $n['V_S'];
        echo '<tr>';
        echo '<th class="font danger">'.$id.'</th>';
        echo '<th class="font">'.$name.'</th>';
        echo '<th class="font">'.$id_P.'</th>';
        echo '<th class="font">'.$text.'</th>';
        echo '<th class="font">'.$date.'</th>';
        if ($V_S == 0){
            echo '<th class="font">'.'منتشر نشود'.'</th>';
        }if ($V_S == 1){
            echo '<th class="font">'.'منتشر شود'.'</th>';
        }

        echo '</tr>';
    }

    ?>
</table>
</body>
</html>
