<?php
include '../inc/config.php';
$sql = "DELETE FROM tbl_imgs WHERE id = '".$_POST['id']."' ";
$stmt=$link->prepare($sql);
$stmt->execute();