<?php
include '../inc/config.php';
$id=$_POST['id'];
$status=$_POST['status'];
$sql="UPDATE `tbl_pm_product` SET `V_S` = '".$status."' WHERE `id` = '".$id."'";
$stmt=$link->prepare($sql);
$stmt->execute();