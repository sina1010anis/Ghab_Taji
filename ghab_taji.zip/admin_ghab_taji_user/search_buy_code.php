<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="../tools/bootstrap.min.css">
    <link rel="stylesheet" href="../tools/bootstrap-theme.min.css">
    <link rel="stylesheet" href="../css/admin_style.css">
    <script src="../tools/jquery-3.3.1.min.js"></script>
    <script src="../tools/bootstrap.min.js"></script>
</head>
<body style="background-color: white!important;">

<table class="table table-bordered">
    <tr>
        <th class="font">ایدی</th>
        <th class="font">نام</th>
        <th class="font">نام خانوادگی</th>
        <th class="font">شهر</th>
        <th class="font">ادرس</th>
        <th class="font">شماره موبایل</th>
        <th class="font">تلفن منزل</th>
        <th class="font">وضعیت پرداختی</th>
        <th class="font">کد کاربری</th>
        <th class="font">نام کاربری</th>
        <th class="font">تاریخ و زمان</th>
        <th class="font">محصولات سفارش داده شده</th>
        <th class="font">تعداد سفارشات</th>
        <th class="font">مجموع کل قیمت</th>
        <th class="font">کد دریافتی درگاه</th>
        <th class="font">کد تراکنشی</th>
        <th class="font">وضعیت سفارش</th>
    </tr>
    <?php

    include '../inc/config.php';
    $sql = "select * from tbl_buy where cookiename like '%" . @$_POST['user_code'] . "%'";
    $stmt = $link->prepare($sql);
    $stmt->execute();
    while ($n = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $id = $n['id'];
        $name = $n['name_user'];
        $family = $n['family_user'];
        $city_user = $n['city_user'];
        $location_user = $n['location_user'];
        $mobile_yser = $n['mobile_yser'];
        $phoneHome_user = $n['phoneHome_user'];
        $T_buy = $n['T_buy'];
        $cookiename = $n['cookiename'];
        $user_name = $n['user_name'];
        $date = $n['date'];
        $product_buy = $n['product_buy'];
        $number_buy = $n['number_buy'];
        $total_price = $n['total_price'];
        $token = $n['token'];
        $code_t = $n['code_t'];
        $status = $n['status'];
        echo '<tr>';
        echo '<th class="font">'.$id.'</th>';
        echo '<th class="font">'.$name.'</th>';
        echo '<th class="font">'.$family.'</th>';
        echo '<th class="font">'.$city_user.'</th>';
        echo '<th class="font">'.$location_user.'</th>';
        echo '<th class="font">'.$mobile_yser.'</th>';
        echo '<th class="font">'.$phoneHome_user.'</th>';
        echo '<th class="font">'.$T_buy.'</th>';
        echo '<th class="font">'.$cookiename.'</th>';
        echo '<th class="font">'.$user_name.'</th>';
        echo '<th class="font">'.$date.'</th>';
        echo '<th class="font">'.$product_buy.'</th>';
        echo '<th class="font">'.$number_buy.'</th>';
        echo '<th class="font">'.$total_price.'</th>';
        echo '<th class="font">'.$token.'</th>';
        echo '<th class="font">'.$code_t.'</th>';
        echo '<th class="font">'.$status.'</th>';
        echo '</tr>';
    }

    ?>
</table>
</body>
</html>
