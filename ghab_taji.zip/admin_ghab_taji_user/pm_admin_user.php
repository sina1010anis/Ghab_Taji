<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="background-color: white!important;">
<table class="table table-bordered">
    <tr>
        <th class="font success">ایدی</th>
        <th class="font success">نام</th>
        <th class="font success">متن</th>
        <th class="font success">تاریخ</th>
    </tr>
    <?php

    include '../inc/config.php';
    $sql = "select * from tbl_pm_admin_user";
    $stmt = $link->prepare($sql);
    $stmt->execute();
    while ($n = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $id = $n['id'];
        $name = $n['email_user'];
        $text = $n['pm'];
        $date = $n['date'];
        echo '<tr>';
        echo '<th class="font danger">'.$id.'</th>';
        echo '<th class="font">'.$name.'</th>';
        echo '<th class="font">'.$text.'</th>';
        echo '<th class="font">'.$date.'</th>';
        echo '</tr>';
    }

    ?>
</table>
</body>
</html>
