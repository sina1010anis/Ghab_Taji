<?php
include '../inc/config.php';
$sql = "DELETE FROM tbl_product WHERE id = '" . $_POST['name'] . "' ";
$stmt = $link->prepare($sql);
$stmt->execute();