<?php
include '../inc/config.php';
$sql = "DELETE FROM tbl_img_slide WHERE id = '".$_POST['idS']."' ";
$stmt=$link->prepare($sql);
$stmt->execute();