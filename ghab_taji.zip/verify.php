<?php
session_start();
include_once("functions.php");
include 'inc/config.php';
$api = 'test';
$token = $_GET['token'];
$result = json_decode(verify($api,$token));
$rand_code=rand(0000,9999).'-'.rand(0000,9999).'-'.rand(0000,9999).'-'.rand(0000,9999);
if(isset($result->status)){
	if($result->status == 1){
        $sqlA="update tbl_buy set T_buy='200' where date='".$_SESSION['time']."' and cookiename='".$_COOKIE['ghab_taji']."' and token='".$token."'";
        $stmtA=$link->prepare($sqlA);
        $stmtA->execute();
        $sqlF="update tbl_buy set code_t='$rand_code' where date='".$_SESSION['time']."' and cookiename='".$_COOKIE['ghab_taji']."' and token='".$token."'";
        $stmtF=$link->prepare($sqlF);
        $stmtF->execute();
        $sqlE="update tbl_basket set T_buy=200 where cookiename='".$_COOKIE['ghab_taji']."'";
        $stmtE=$link->prepare($sqlE);
        $stmtE->execute();
		include 'ok_buy.php';
	} else {
        $sqlB="update tbl_buy set T_buy='404' where date='".$_SESSION['time']."' and cookiename='".$_COOKIE['ghab_taji']."' and token='".$token."'";
        $stmtC=$link->prepare($sqlC);
        $stmtC->execute();
        include 'no_buy.php';
	}
} else {
	if($_GET['status'] == 0){
        $sqlD="update tbl_buy set T_buy='404' where date='".$_SESSION['time']."' and cookiename='".$_COOKIE['ghab_taji']."' and token='".$token."'";
        $stmtD=$link->prepare($sqlD);
        $stmtD->execute();
		echo "<h1>تراکنش با خطا مواجه شد</h1>";
	}}