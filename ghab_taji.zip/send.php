<?php
session_start();
include_once("functions.php");
include 'inc/config.php';
$sql="select * from tbl_buy where date='".$_SESSION['time']."' and cookiename='".$_COOKIE['ghab_taji']."'";
$stmt=$link->prepare($sql);
$stmt->execute();
$n=$stmt->fetch(PDO::FETCH_ASSOC);
$price=$n['total_price'];
$api = 'test';
$amount =$price ;
$mobile = "09395231890";
$factorNumber = "شماره فاکتور";
$description = "توضیحات";
$redirect = 'http://localhost/s1/ghab_taji/verify.php';
$result = send($api, $amount, $redirect);
$result = json_decode($result);
if($result->status) {
	$go = "https://pay.ir/pg/$result->token";
	header("Location: $go");
    $sqlA="update tbl_buy set token='".$result->token."' where date='".$_SESSION['time']."' and cookiename='".$_COOKIE['ghab_taji']."'";
    $stmtA=$link->prepare($sqlA);
    $stmtA->execute();
    $sqlA="update tbl_buy set T_buy=100 where date='".$_SESSION['time']."' and cookiename='".$_COOKIE['ghab_taji']."'";
    $stmtA=$link->prepare($sqlA);
    $stmtA->execute();
} else {
	echo $result->errorMessage;
    $sqlB="update tbl_buy set T_buy=404 where date='".$_SESSION['time']."' and cookiename='".$_COOKIE['ghab_taji']."'";
    $stmtB=$link->prepare($sqlB);
    $stmtB->execute();
}